Football Theme Pack — Prototype Assets

This pack follows THEME-ART-SPEC-v2.

IMPORTANT RENDERING LAYERS
- bg.webp / bg-dark.webp: wallpaper behind the whole screen. It is intentionally quiet in the board area.
- board-art.png: transparent, faint theme motifs for the board surface. The app should fade this to approximately 10–15%.
- st.png: transparent center emblem. It is a separate overlay placed at the board center, roughly 1.5 squares wide, BELOW letter tiles. It is NOT part of the wallpaper or board-art.
- tw.svg, dw.svg, tl.svg, dl.svg: independent white silhouette icons on transparent backgrounds. The game paints the premium square color behind each icon.
- surface.webp: optional seamless board texture; keep subtle.
- tile.svg and rack.svg: optional theme material/tray styling.
- particle.png, burst.png, pop.png, st-anim.png: sprite strips, left-to-right, equally sized frames.
- pick/drop/bad/play/bingo/win/computer.mp3: original prototype synthesized sounds.

The frame.png file is intentionally omitted to keep the interface clean; use a thin theme-colored 1px outline.
No gameplay rules or score logic are included.
